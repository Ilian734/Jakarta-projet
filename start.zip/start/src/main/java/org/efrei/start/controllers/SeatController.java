package org.efrei.start.controllers;

import org.efrei.start.dto.CreateSeat;
import org.efrei.start.models.Room;
import org.efrei.start.models.Seat;
import org.efrei.start.repositories.RoomRepository;
import org.efrei.start.repositories.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/seats")
public class SeatController {

    @Autowired
    private SeatRepository seatRepository;

    @Autowired
    private RoomRepository roomRepository; // Pour récupérer la salle

    @PostMapping
    public ResponseEntity<Seat> createSeat(@RequestBody CreateSeat createSeat) {
        Room room = roomRepository.findById(createSeat.getRoomId()).orElse(null); // Récupérer la salle par ID
        if (room == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Salle non trouvée
        }
        Seat newSeat = new Seat(createSeat.getRowNumber(), createSeat.getSeatNumber(), createSeat.isAvailable(), room);
        Seat savedSeat = seatRepository.save(newSeat);
        return new ResponseEntity<>(savedSeat, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Seat>> findAll() {
        List<Seat> seats = seatRepository.findAll();
        return new ResponseEntity<>(seats, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Seat> findById(@PathVariable String id) {
        Seat seat = seatRepository.findById(id).orElse(null);
        if (seat == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(seat, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Seat> updateSeat(@PathVariable String id, @RequestBody CreateSeat createSeat) {
        if (!seatRepository.existsById(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        Room room = roomRepository.findById(createSeat.getRoomId()).orElse(null); // Vérifier la salle
        if (room == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Salle non trouvée
        }
        Seat updatedSeat = new Seat(createSeat.getRowNumber(), createSeat.getSeatNumber(), createSeat.isAvailable(), room);
        updatedSeat.setId(id); // Assurez-vous de mettre l'ID correct
        seatRepository.save(updatedSeat);
        return new ResponseEntity<>(updatedSeat, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSeat(@PathVariable String id) {
        if (!seatRepository.existsById(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        seatRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
