package org.efrei.start;

import org.efrei.start.models.Room;
import org.efrei.start.models.Seat;
import org.efrei.start.repositories.RoomRepository;
import org.efrei.start.repositories.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final RoomRepository roomRepository;
    private final SeatRepository seatRepository;

    @Autowired
    public DataInitializer(RoomRepository roomRepository, SeatRepository seatRepository) {
        this.roomRepository = roomRepository;
        this.seatRepository = seatRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        for (int i = 1; i <= 20; i++) {
            Room room = new Room("Salle " + i);
            roomRepository.save(room);
            createSeatsForRoom(room);
        }
    }

    private void createSeatsForRoom(Room room) {
        for (int row = 1; row <= 6; row++) {
            for (int seat = 1; seat <= 20; seat++) {
                Seat newSeat = new Seat(row, seat, true, room);
                seatRepository.save(newSeat);
            }
        }
    }
}

