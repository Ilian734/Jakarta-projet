package org.efrei.start.dto;

public class CreateSeat {

    private int rowNumber;
    private int seatNumber;
    private boolean isAvailable;
    private String roomId; // Ajout de roomId

    // Getters and Setters
    public int getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public int getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(int seatNumber) {
        this.seatNumber = seatNumber;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getRoomId() {
        return roomId; // Getter pour roomId
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId; // Setter pour roomId
    }
}
