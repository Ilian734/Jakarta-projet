package org.efrei.start.services;

import org.efrei.start.dto.CreateSeat;
import org.efrei.start.models.Seat;
import org.efrei.start.repositories.SeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatService {

    private final SeatRepository repository;

    @Autowired
    public SeatService(SeatRepository repository) {
        this.repository = repository;
    }

    public List<Seat> findAll() {
        return repository.findAll();
    }

    public void create(CreateSeat createSeat) {
        Seat seat = new Seat();
        seat.setRowNumber(createSeat.getRowNumber());
        seat.setSeatNumber(createSeat.getSeatNumber());
        seat.setAvailable(createSeat.isAvailable());
        repository.save(seat);
    }

    public Seat findById(String id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteById(String id) {
        repository.deleteById(id);
    }

    public void update(String id, Seat seat) {
        Seat updatedSeat = findById(id);
        if (updatedSeat != null) {
            updatedSeat.setRowNumber(seat.getRowNumber());
            updatedSeat.setSeatNumber(seat.getSeatNumber());
            updatedSeat.setAvailable(seat.isAvailable());
            repository.save(updatedSeat);
        }
    }
}
